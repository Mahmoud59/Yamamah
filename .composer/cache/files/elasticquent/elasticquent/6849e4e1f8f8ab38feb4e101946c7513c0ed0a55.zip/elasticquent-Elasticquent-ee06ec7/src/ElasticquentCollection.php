<?php namespace Elasticquent;

class ElasticquentCollection extends \Illuminate\Database\Eloquent\Collection
{

    use ElasticquentCollectionTrait;

}