<?php

namespace PragmaRX\Support;

use Illuminate\Cache\CacheManager as IlluminateCacheManager;

class CacheManager extends IlluminateCacheManager {

}
